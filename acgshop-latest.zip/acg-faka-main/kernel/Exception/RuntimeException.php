<?php
declare (strict_types=1);

namespace Kernel\Exception;


class RuntimeException extends \Exception
{

}