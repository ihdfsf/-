<?php
declare(strict_types=1);

namespace App\Consts;


interface User
{
    const SESSION = "USER_SESSION";
}